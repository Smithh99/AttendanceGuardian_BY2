Attendance Guardian BY2 - Web Version

Open index.html in a browser. The app stores attendance locally on the device.
Enter exact current attendance per subject before using calculations.

Target period: 14 Sep 2026 to 30 Dec 2026
Minimum target: 80%
Recovery target: 90%

Note: timetable data was intentionally not invented. Add the real timetable before implementing lecture-specific 5-minute reminders.
