# Attendance Guardian — BY2

Android attendance planner for the BY2 batch.

## Current settings
- Start date: 14 September 2026
- End date: 30 December 2026
- Minimum attendance target: 80%
- Recovery goal: 90%
- Lecture reminder: 5 minutes before the scheduled start
- Starting attendance: 124 present / 131 conducted (94.66%)

## Build APK on GitHub from a phone
1. Upload the contents of this project to the repository root.
2. Open **Actions**.
3. Select **Build Attendance Guardian BY2 APK**.
4. Tap **Run workflow** (or push a commit to trigger it).
5. Wait for the green check.
6. Open the completed run and download **AttendanceGuardian-BY2-APK** under Artifacts.

No `gradlew` wrapper is required: the workflow installs Gradle 8.11.1 directly.
