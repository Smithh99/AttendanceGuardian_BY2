package com.smit.attendanceguardian;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public final class Schedule {
    public static class Slot {
        public final DayOfWeek day; public final String start, subject, room;
        Slot(DayOfWeek d,String s,String sub,String r){day=d;start=s;subject=sub;room=r;}
    }
    // Common theory periods visible in the supplied timetable. Practical/group periods are
    // included as BY1/BY2/BY3 entries; change BATCH below to match your group.
    public static final String BATCH="BY2";
    public static final List<Slot> SLOTS = Arrays.asList(
      new Slot(DayOfWeek.MONDAY,"07:30","FoEE",""),
      new Slot(DayOfWeek.MONDAY,"08:25","FoEM",""),
      new Slot(DayOfWeek.MONDAY,"09:50","FoEE",""),
      new Slot(DayOfWeek.MONDAY,"10:45","ES-DR",""),
      new Slot(DayOfWeek.MONDAY,"11:50","ECS",""),
      new Slot(DayOfWeek.MONDAY,"12:45","ECS",""),
      new Slot(DayOfWeek.TUESDAY,"07:30","EG&CAD",""),
      new Slot(DayOfWeek.TUESDAY,"08:25","EG&CAD",""),
      new Slot(DayOfWeek.TUESDAY,"09:50","TL",""),
      new Slot(DayOfWeek.TUESDAY,"10:45","TL",""),
      new Slot(DayOfWeek.TUESDAY,"11:50","FoEE",""),
      new Slot(DayOfWeek.WEDNESDAY,"07:30","FoEE",""),
      new Slot(DayOfWeek.WEDNESDAY,"08:25","ECS",""),
      new Slot(DayOfWeek.WEDNESDAY,"09:50","FoEM",""),
      new Slot(DayOfWeek.WEDNESDAY,"10:45","FoCE",""),
      new Slot(DayOfWeek.WEDNESDAY,"11:50","FoEM",""),
      new Slot(DayOfWeek.WEDNESDAY,"12:45","FoEM",""),
      new Slot(DayOfWeek.THURSDAY,"07:30","FoEE",""),
      new Slot(DayOfWeek.THURSDAY,"08:25","PY",""),
      new Slot(DayOfWeek.THURSDAY,"09:50","FoEM",""),
      new Slot(DayOfWeek.THURSDAY,"10:45","ES-DR",""),
      new Slot(DayOfWeek.THURSDAY,"11:50","FoCE",""),
      new Slot(DayOfWeek.THURSDAY,"12:45","FoCE",""),
      new Slot(DayOfWeek.FRIDAY,"07:30","FoEE",""),
      new Slot(DayOfWeek.FRIDAY,"08:25","PY",""),
      new Slot(DayOfWeek.FRIDAY,"09:50","PY",""),
      new Slot(DayOfWeek.FRIDAY,"10:45","ECS",""),
      new Slot(DayOfWeek.FRIDAY,"11:50","EG&CAD",""),
      new Slot(DayOfWeek.FRIDAY,"12:45","FoCE","")
    );
    public static String subjectKey(String s){return s.replace("&","and").replace("-","_").replace(" ","");}
    public static String subjectName(String s){
      if(s.equals("FoCE")) return "Fundamentals of Civil Engineering";
      if(s.equals("FoCE-PR")) return "Fundamentals of Civil Engineering-PR";
      if(s.equals("FoEE")) return "Fundamentals of Electrical Engineering";
      if(s.equals("FoEM")) return "Fundamentals of Engineering Mathematics";
      if(s.equals("ES-DR")) return "Environmental Sustainability & Disaster Risk Reduction";
      if(s.equals("ECS")) return "Effective Communication Skills";
      if(s.equals("EG&CAD")) return "Engineering Graphics & CAD";
      if(s.equals("TL")) return "Tinkering to IoT Systems";
      if(s.equals("PY")) return "Practical / group session";
      return s;
    }
}
