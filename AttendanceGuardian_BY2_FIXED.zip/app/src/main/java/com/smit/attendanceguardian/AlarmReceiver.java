package com.smit.attendanceguardian;

import android.app.*;
import android.content.*;
import android.os.*;
import java.time.*;
import java.util.*;

public class AlarmReceiver extends BroadcastReceiver {
    static final String CH="attendance_reminders";
    @Override public void onReceive(Context c, Intent in){
        String subject=in.getStringExtra("subject");
        String time=in.getStringExtra("time");
        if(subject==null){return;}
        android.content.SharedPreferences p=c.getSharedPreferences("attendance",Context.MODE_PRIVATE);
        int pr=p.getInt("present",124), held=p.getInt("held",131);
        float overall=100f*pr/Math.max(1,held);
        String k=Schedule.subjectKey(subject);
        int sp=p.getInt("sp_"+k,0), sh=p.getInt("sh_"+k,0);
        float sub=(sh==0?0:100f*sp/sh);
        float projected=100f*pr/(held+1f);
        float projectedSub=100f*sp/(sh+1f);
        float target=p.getFloat("target",80f), goal=p.getFloat("goal",90f);
        String msg=String.format(Locale.US,
          "%s starts at %s (5 min). Subject: %.2f%% (%d/%d). If absent → %.2f%%. Overall: %.2f%%; if absent → %.2f%%.",
          Schedule.subjectName(subject),time,sub,sp,sh,projectedSub,overall,projected);
        if(projected<target || projectedSub<target) msg+=" ⚠️ This absence would put you below your "+target+"% target.";
        int need=(int)Math.max(0,Math.ceil((goal*held/100f-pr)/(1-goal/100f)));
        if(overall<goal && need>0) msg+=" To reach "+String.format(Locale.US,"%.0f",goal)+"% overall, attend the next "+need+" lectures continuously.";
        fireNow(c,Schedule.subjectName(subject),msg);
    }
    static void fireNow(Context c,String title,String msg){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CH,"Attendance reminders",NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(msg)
         .setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
    static void scheduleAll(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        LocalDate start=LocalDate.of(2026,9,14), end=LocalDate.of(2026,12,30);
        int id=1000;
        for(LocalDate d=start;!d.isAfter(end);d=d.plusDays(1)){
          for(Schedule.Slot s:Schedule.SLOTS){
            if(s.day!=DayOfWeek.of(d.getDayOfWeek().getValue())) continue;
            LocalTime lt=LocalTime.parse(s.start).minusMinutes(5);
            ZonedDateTime z=ZonedDateTime.of(d,lt,ZoneId.systemDefault());
            if(z.toInstant().toEpochMilli()<=System.currentTimeMillis()) continue;
            Intent i=new Intent(c,AlarmReceiver.class).putExtra("subject",s.subject).putExtra("time",s.start);
            PendingIntent pi=PendingIntent.getBroadcast(c,id++,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if(Build.VERSION.SDK_INT>=31) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,z.toInstant().toEpochMilli(),pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,z.toInstant().toEpochMilli(),pi);
          }
        }
    }
}
