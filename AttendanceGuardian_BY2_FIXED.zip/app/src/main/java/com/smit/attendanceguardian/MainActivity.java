package com.smit.attendanceguardian;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int NOTIF_REQ=7;
    android.content.SharedPreferences p;
    EditText present,total,target,goal;
    TextView status,plan;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        p=getSharedPreferences("attendance",MODE_PRIVATE);
        present=findViewById(R.id.present); total=findViewById(R.id.total);
        target=findViewById(R.id.target); goal=findViewById(R.id.goal);
        status=findViewById(R.id.status); plan=findViewById(R.id.plan);
        present.setText(""+p.getInt("present",124));
        total.setText(""+p.getInt("held",131));
        target.setText(""+p.getFloat("target",80f));
        goal.setText(""+p.getFloat("goal",90f));
        findViewById(R.id.save).setOnClickListener(v->saveAndSchedule());
        findViewById(R.id.test).setOnClickListener(v->{
            AlarmReceiver.fireNow(this,"TEST","This is a test reminder. Your Attendance Guardian notifications are working.");
        });
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIF_REQ);
        refresh();
    }

    void saveAndSchedule(){
        int pr=Integer.parseInt(present.getText().toString());
        int held=Integer.parseInt(total.getText().toString());
        float tg=Float.parseFloat(target.getText().toString());
        float gl=Float.parseFloat(goal.getText().toString());
        p.edit().putInt("present",pr).putInt("held",held).putFloat("target",tg).putFloat("goal",gl).apply();
        // First-run subject figures from the supplied attendance screenshots.
        seedSubjects();
        AlarmReceiver.scheduleAll(this);
        refresh();
        Toast.makeText(this,"Saved. 5-minute lecture reminders scheduled.",Toast.LENGTH_LONG).show();
    }

    void seedSubjects(){
        String[][] a={
          {"ECS","3","6"},{"ECS-PR","5","8"},{"EG&CAD","7","11"},{"ES-DR","10","13"},
          {"FoCE","21","23"},{"FoCE-PR","4","6"},{"FoEE","21","21"},{"FoEE-PR","8","8"},
          {"FoEM","16","16"},{"FoEM-TU","15","15"},{"TL","5","5"},{"TL-PR","9","13"}
        };
        android.content.SharedPreferences.Editor e=p.edit();
        for(String[] x:a){
          String k=Schedule.subjectKey(x[0]);
          if(!p.contains("sp_"+k)) e.putInt("sp_"+k,Integer.parseInt(x[1])).putInt("sh_"+k,Integer.parseInt(x[2]));
        }
        e.apply();
    }

    void refresh(){
        int pr=p.getInt("present",124), held=p.getInt("held",131);
        float pct=held==0?0:100f*pr/held;
        float tg=p.getFloat("target",80), gl=p.getFloat("goal",90);
        status.setText(String.format(Locale.US,"Overall: %.2f%%  (%d / %d)\\nMinimum: %.0f%% • Recovery goal: %.0f%%",pct,pr,held,tg,gl));
        int need90=(int)Math.max(0,Math.ceil((gl*held/100f-pr)/(1-gl/100f)));
        plan.setText(need90==0 ? "You are already at/above the recovery goal." :
          "To reach "+String.format(Locale.US,"%.0f",gl)+"%: attend the next "+need90+" lectures continuously.");
    }
}
